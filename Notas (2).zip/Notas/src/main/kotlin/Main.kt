import javax.swing.JOptionPane
fun main(args:Array<String>){

    var cantAlumnos=JOptionPane.showInputDialog(" ingresa la cantidad de Estudiantes").toInt()
    var a=Array<Alumnos?>(cantAlumnos){null}
    for (i in 0 until cantAlumnos){
        var nombre=JOptionPane.showInputDialog(" ingrese el nombre de Estudiantes ${i+1}")
        var aula=JOptionPane.showInputDialog("ingrese el aula de Estudiantes ${i+1}")[0]
        var calificacion=JOptionPane.showInputDialog("ingrese la nota primero  ${i+1}").toDouble()
        var calificacion1=JOptionPane.showInputDialog("ingrese la nota segunda  ${i+1}").toDouble()
        var calificacion2=JOptionPane.showInputDialog("ingrese la nota tercera  ${i+1}").toDouble()

        a[i]=Alumnos(nombre, aula)
        a[i]!!.calificacion=calificacion
    }
     var suma=0.0
    var promedio=0.0
    var cantAlumnosPorSalon=0
    var salon=JOptionPane.showInputDialog(" ingresa el salon de los Estudiantes a promediar")[0]
    for(i in 0 until cantAlumnos){
        if(salon==a[i]!!.aula){
            suma=suma+a[i]!!.calificacion
            cantAlumnosPorSalon++
        }
    }
    promedio=suma/cantAlumnosPorSalon
    JOptionPane.showMessageDialog(null,"El promedio de los Estudiantes del salon $salon es $promedio")
}

